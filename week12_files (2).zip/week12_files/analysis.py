import pandas as pd


def 정제(df: pd.DataFrame) -> pd.DataFrame:
    정제된_df = df.copy()
    print("시작:", len(정제된_df))

    # 점수가 비어 있는 행을 삭제한다.
    정제된_df = 정제된_df.dropna(subset=["점수"])
    print("빈 칸 제거 후:", len(정제된_df))

    # 모든 열의 값이 완전히 같은 중복 행을 제거한다.
    정제된_df = 정제된_df.drop_duplicates()
    print("중복 제거 후:", len(정제된_df))

    # 반과 과목 값의 앞뒤 공백을 제거한다.
    정제된_df["반"] = 정제된_df["반"].str.strip()
    정제된_df["과목"] = 정제된_df["과목"].str.strip()
    print("공백 제거 후:", len(정제된_df))

    # 점수가 0~100 범위를 벗어난 행을 삭제한다.
    정제된_df = 정제된_df[
        (정제된_df["점수"] >= 0) & (정제된_df["점수"] <= 1000)
    ].copy()
    print("범위 밖 제거 후:", len(정제된_df))

    return 정제된_df


def 반별통계(df: pd.DataFrame) -> pd.DataFrame:
    return df.groupby("반")["점수"].agg(
        개수="count",
        평균="mean",
        중앙값="median",
        최댓값="max",
    ).round(2)


def 반별평균(df: pd.DataFrame) -> dict[str, float]:
    return df.groupby("반")["점수"].mean().round(2).to_dict()


if __name__ == "__main__":
    df = 정제(pd.read_csv("scores_2026.csv"))

    수학_df = df[df["과목"] == "수학"]
    print("수학 행 수:", len(수학_df))
    print("1반이고 90점 이상인 행:")
    print(df[(df["반"] == "1반") & (df["점수"] >= 90)])

    반별_평균 = df.groupby("반")["점수"].mean().round(2)
    과목별_반별_평균 = df.groupby(["과목", "반"])["점수"].mean().round(2)
    print("반별 평균:")
    print(반별_평균)
    print("과목·반별 평균:")
    print(과목별_반별_평균)

    print("반별 통계:")
    print(반별통계(df))
    print("반별 평균 딕셔너리:")
    print(반별평균(df))