import pandas as pd

from analysis import 반별평균, 정제


본 = 정제(pd.read_csv("scores_2026.csv"))
미니 = 정제(pd.read_csv("mini.csv"))


def test_본데이터를_정제하면_100행이_남는다():
    assert len(본) == 100


def test_정제후_반은_두종류만_남는다():
    assert sorted(본["반"].unique()) == ["1반", "2반"]


def test_그룹합이_전체합과_같다():
    assert 본.groupby("반")["점수"].sum().sum() == 본["점수"].sum()


def test_미니데이터_1반평균이_손계산과_같다():
    assert 반별평균(미니)["1반"] == 80.0